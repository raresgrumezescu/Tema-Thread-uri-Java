import java.lang.*;
import java.io.*;
import java.util.*;
//import java.io.EOFException;

public class MyThread2 extends Thread {
    //public Task2 task;
    public int id;

    public MyThread2(int id) {
        this.id = id;
        //this.task = task;
    }

    public int fibo(int value) {
        if (value == 0)
            return 1;
        if (value == 1)
            return 1;

        return fibo(value - 1) + fibo(value - 2);
    }

    public void run() {
//        try {
        //    if (id == 1) {
        Task2 task;
        for (int i = id; i < Tema2.taskuri2.size(); i += Tema2.nr_workeri) {
            task = Tema2.taskuri2.get(i);
            int S = 0;
            int nr_cuv_total = 0;
            int lungime_maxima = -20000;
            int nr_aparitii_lungime_maxima = 0;
            for (Map.Entry<Integer, Integer> m : task.dictionar.entrySet()) {
                int key = m.getKey(), value = m.getValue();
                S += fibo(key) * value;
                nr_cuv_total += value;
                //System.out.println(key + "  " + value + "  " + fibo(key));
                if (lungime_maxima < key) {
                    lungime_maxima = key;
                    nr_aparitii_lungime_maxima = value;
                }
            }

            //System.out.println(S + "   " + nr_cuv_total);

            double rang = (double) S / nr_cuv_total;

            //System.out.println(task.nume_fisier + "," + String.format("%.2f", rang) + "," + lungime_maxima + "," + nr_aparitii_lungime_maxima);
//            Tema2.taskuri2.get(i).rank = rang;
            StringTokenizer token = new StringTokenizer(task.nume_fisier, "/");
            String numeFile = "";
            while (token.hasMoreTokens()) {
                //System.out.println(token.nextToken().length());
                numeFile = token.nextToken();
            }

            String output = "";

            output = numeFile + "," + String.format("%.2f", rang) + "," + lungime_maxima + "," + nr_aparitii_lungime_maxima + "\n";

            //Tema2.output_uri[i] = new Outputuri(output, rang);

            Tema2.arr_out.add(new Outputuri(output, rang));

            //System.out.println(output);

            //synchronized (this) {
        /*
            try {

                Tema2.buffer.write(output);
                //buffer.close();
            } catch (IOException ex) {
                System.out.println("Something went Wrong");
                ex.printStackTrace();
            }

         */
            //}

//        } catch (IOException ex) {
//            System.out.println("Something went Wrong");
//            ex.printStackTrace();
//        }
        }
    }
   // }
}