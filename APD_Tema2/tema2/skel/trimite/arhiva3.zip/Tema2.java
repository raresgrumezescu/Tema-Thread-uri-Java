import java.io.*;
import java.util.*;


public class Tema2 {

    public static String for_check = ";:/?˜\\.,><‘[]{}()!@#$%ˆ&-   +’=*| \t\n\r'";

    //public static String for_check = ";:/?~\\\\.,><`[]{}()!@#$%^&-_+'=*\\\"| \\t\\r\\n ";

    //public static String for_check = ";:/?";

    //public static char[][] contents = new char[10000][10000];

    //public static Vector<Rezultat> rezultate = new Vector<Rezultat>();

    public static Rezultat[] rezultate;

    public static BufferedWriter buffer;

    public static String outFile;
    //public static FileWriter fw;
    public static int nr_workeri;

    public static Vector<Task> taskuri;

    public static Vector<Task2> taskuri2;

    public static Outputuri[] output_uri;

    public static Vector<Outputuri> arr_out;

    public static void main(String[] args) {
        if (args.length < 3) {
            System.err.println("Usage: Tema2 <workers> <in_file> <out_file>");
            return;
        }
        BufferedReader reader;
        Vector<String> fisiere = new Vector<String>();

        //int nr_workeri = Integer.parseInt(args[0]);
        nr_workeri = Integer.parseInt(args[0]);
        taskuri = new Vector<Task>();
        outFile = args[2];

        //System.out.println(for_check);

        try {
            reader = new BufferedReader(new FileReader(args[1]));
            buffer = new BufferedWriter(new FileWriter(Tema2.outFile));

            String line = reader.readLine();
            while (line != null) {

                fisiere.add(line);

                line = reader.readLine();
            }
            reader.close();
            //for (int i = 0; i < fisiere.size(); i++)
            //    System.out.println(fisiere.get(i));

            int dimensiune_fragment = 0, nr_documente = 0, id = 0;
            int id_file = 0;

            for (int i = 0; i < fisiere.size(); i++) {
                if (i == 0) {
                    dimensiune_fragment = Integer.parseInt(fisiere.get(i));
                    continue;
                }
                if (i == 1) {
                    nr_documente = Integer.parseInt(fisiere.get(i));
                    continue;
                }

                String fname = fisiere.get(i);
                // Passing the path to the file as a parameter
                FileReader fr = new FileReader(fname);

                // Declaring loop variable
                int j, count = 0, offset = 0;
                // Holds true till there is nothing to read
                while ((j = fr.read()) != -1) {
                   // contents[id_file][count] = (char) j;
                    count++;
                    // Print all the content of a file
              //      System.out.print((char) j);
                }

                //System.out.println();

                while (count >= 0) {
                    count -= dimensiune_fragment;
                    if (count >= 0)
                        taskuri.add(new Task(fname, offset, dimensiune_fragment, id++, id_file));
                    else
                        taskuri.add(new Task(fname, offset, count + dimensiune_fragment, id++, id_file));
                    offset += dimensiune_fragment;
                }

                id_file++;
            }

            Thread[] t = new Thread[nr_workeri];
/*
            for (int i = 0; i < nr_workeri; ++i) {
                //Vector<Task> tasks_wi = new Vector<Task>();
                for (int j = 0; j < taskuri.size(); ++j) {
                    for (int k = 0; k < nr_workeri; ++k) {
                        if ((i + 1) % nr_workeri == k)
                    }
                }

                System.out.println();
                //t[i] = new MyThread(i, tasks_wi);
                t[i] = new MyThread(i);
                t[i].start();
            }
*/
//            System.out.println(taskuri);



            rezultate = new Rezultat[taskuri.size()];

            for (int i = 0; i < nr_workeri; ++i) {

                /*
                Vector<Task> tasks_wi = new Vector<Task>();
                for (int j = 0; j < taskuri.size(); ++j) {
                    if (((j) % nr_workeri) == (i))
                        tasks_wi.add(taskuri.get(j));
                }
                */
            //    System.out.println(tasks_wi);

                t[i] = new MyThread(i);
                t[i].start();
            }

            for (int i = 0; i < nr_workeri; ++i) {
                try {
                    t[i].join();
                    //System.out.println("Thread " + i + " computed result " + ((Task)t[i]).getResult() + ".");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            int from = 0;

            taskuri2 = new Vector<Task2>();

            for (int i = 0; i < nr_documente; ++i) {
                Vector<Rezultat> tasks_wi = new Vector<Rezultat>();

                String actual_file = rezultate[from].nume_fisier;

                for (int j = from; j < taskuri.size(); j++) {
                    //System.out.println(actual_file);
                    if (rezultate[j].nume_fisier.equals(actual_file) == false) {
                        from = j;
                        actual_file = rezultate[j].nume_fisier;
                        break;
                    }
                    tasks_wi.add(rezultate[j]);
                }
                //System.out.println(tasks_wi);

                Map<Integer, Integer> map_rez = new HashMap<Integer, Integer>();
                Vector<String> maxWords_rez = new Vector<String>();
                int maxLength = -20000;
                for (Rezultat r : tasks_wi) {
                    if (r.maxWords.size() > 0) {
                        for (Map.Entry<Integer, Integer> m : r.dictionar.entrySet()) {
                            int key = m.getKey();
                            //int value = m.getValue();
                            map_rez.putIfAbsent(key, 0);
                            int value = map_rez.get(key);
                            value += m.getValue();
                            //System.out.println(m.get(key));
                            map_rez.replace(key, value);
                        }

                        if (r.maxWords.firstElement().length() > maxLength) {
                            maxLength = r.maxWords.firstElement().length();
                            maxWords_rez.clear();
                            maxWords_rez = new Vector<String>(r.maxWords);
                        } else if (r.maxWords.firstElement().length() == maxLength) {
                            maxWords_rez.addAll(r.maxWords);
                        }

                    }
                }

                Task2 task2 = new Task2(tasks_wi.firstElement().nume_fisier, map_rez, maxWords_rez);
                taskuri2.add(task2);

                //System.out.println(task2);

        //        t[i] = new MyThread2(i, task2);
        //        t[i].start();
            }
/*
            for (int i = 0; i < taskuri2.size(); i++) {
                System.out.println(taskuri2.get(i));
            }
*/
            output_uri = new Outputuri[taskuri2.size()];

            arr_out = new Vector<Outputuri>();

            for (int i = 0; i < nr_workeri; i++) {
                t[i] = new MyThread2(i);
                t[i].start();
            }

            for (int i = 0; i < nr_workeri; ++i) {
                try {
                    t[i].join();
                    //System.out.println("Thread " + i + " computed result " + ((Task)t[i]).getResult() + ".");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            //ArrayList<Outputuri> arr_out = output_uri.toList();
            Collections.sort(arr_out, new SortByRank());

            for (int i = 0; i < arr_out.size(); i++) {
                //System.out.println(arr_out.get(i).output + "  " + arr_out.get(i).rank);
                buffer.write(arr_out.get(i).output);
            }



            buffer.close();



/*
            for (Rezultat r : rezultate) {
                System.out.println(r);
            }
*/
            /*
            for (int i = 0; i < taskuri.size(); i++) {
                Task t = taskuri.get(i);
                System.out.println("Task[" + i + "] :  nume_fisier = " + t.nume_fisier + " ; offser = " + t.offset + " ; dimensiune = " + t.dimensiune);
            }
            */
/*
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 33; j++)
                    System.out.print(contents[i][j]);
                System.out.println();
            }
*/
        //    System.out.println(for_check);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
