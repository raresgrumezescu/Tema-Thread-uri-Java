import java.io.*;
import java.lang.*;
import java.util.*;

class SortByRank implements Comparator<Outputuri> {

    // Method
    // Sorting in ascending order of roll number
    @Override
    public int compare(Outputuri a, Outputuri b)
    {

        return Double.compare(b.rank, a.rank);
    }
}
/*
import java.util.Comparator;
public class CustomComparator implements Comparator<ReduceTaskResult> {     @Override     public int compare(ReduceTaskResult o1, ReduceTaskResult o2) {         return Double.compare(o2.rank, o1.rank);     } }

 */