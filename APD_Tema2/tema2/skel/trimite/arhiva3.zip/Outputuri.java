public class Outputuri {
    String output;
    double rank;

    Outputuri (String output, double rank) {
        this.output = output;
        this.rank = rank;
    }
}