import java.lang.*;
import java.io.*;
import java.util.*;
//import java.io.EOFException;

public class MyThread extends Thread {
    public Vector<Task> tasks = new Vector<Task>();
    public int id;

    public MyThread(int id) {
        this.id = id;
        //this.tasks = tasks;
    }

    public void afiseaza() {

    }

    public void run() {
        //if (id == 2) {
            try {
                for (int i = id; i < Tema2.taskuri.size(); i += Tema2.nr_workeri) {
                    //System.out.println("Thread[" + id + "]    Task :   " + Tema2.taskuri.get(i));
                    //System.out.println("Task[" + i + "]" );
                    Task t;
                    t = Tema2.taskuri.get(i);
                    int offset = t.offset;
                    int dimensiune = t.dimensiune;
                    RandomAccessFile file = new RandomAccessFile(t.nume_fisier, "r");
                    file.seek(offset);

                    String seq = "";
                    seq += (char) file.read();
                    //System.out.println ((char) file.read());

                    if (offset != 0 && Tema2.for_check.contains(seq) == false) {
                        //System.out.println(seq);
                        file.seek(offset - 1);
                        seq = "";
                        seq += (char) file.read();
                        if (Tema2.for_check.contains(seq) == false) {
                            //System.out.println(seq);
                            //file.seek(offset);
                            //seq = "";
                            //seq += (char) file.read();
                            //System.out.println(seq);
                            /*
                            for (int j = t.offset; j < t.offset + t.dimensiune; j++) {
                                if (Tema2.for_check.contains(seq) == false) {
                                    offset++;
                                    dimensiune--;
                                    seq = "";
                                    seq += (char) file.read();
                                    System.out.println(offset + "   " + dimensiune);
                                } else
                                    break;
                            }
                            */

                            while (true) {

                                seq = "";
                                int ch = file.read();
                                //try {
                                seq += (char) ch;
                                //} catch (EOFException ex) {
                                //System.out.println("aici");
                                //    break;
                                //}
                                if (ch < 0)
                                    break;
                                if (Tema2.for_check.contains(seq) != false) {
                                    //break;
                                    //System.out.println("aici");
                                    break;
                                }
                                offset++;
                                dimensiune--;
                            //    System.out.println(offset + "   " + dimensiune);
                            }



                            t.offset = offset;
                            t.dimensiune = dimensiune;
                            //System.out.println();
                        }
                    }

                    offset = t.offset;
                    dimensiune = t.dimensiune;
                    file.seek(offset + dimensiune - 1);

                    seq = "";
                    seq += (char) file.read();
                    //System.out.println(seq);
                    if (dimensiune != 0 && Tema2.for_check.contains(seq) == false) {
                        //System.out.println(seq);
                        file.seek(offset + dimensiune - 1);
                        seq = "";
                        seq += (char) file.read();
                        if (Tema2.for_check.contains(seq) == false) {
                            //System.out.println(seq);
                            //file.seek(offset);
                            //file.seek(offset + dimensiune);
                            //System.out.println(seq);
                            while (true) {
                                seq = "";
                                int ch = file.read();
                                //try {
                                    seq += (char) ch;
                                //} catch (EOFException ex) {
                                    //System.out.println("aici");
                                //    break;
                                //}
                                if (ch < 0)
                                    break;
                                if (Tema2.for_check.contains(seq) != false) {
                                    //break;
                                    //System.out.println("aici");
                                    break;
                                }
                                dimensiune++;
                             //   System.out.println(offset + "   " + dimensiune);
                            }

                            //t.offset = offset;
                            t.dimensiune = dimensiune;

                        //    System.out.println();
                        }
                    }

                    if (t.dimensiune == 0) {
                        Map<Integer, Integer> map = new HashMap<Integer, Integer>();
                        Vector<String> maxWords = new Vector<String>();
                        map.clear();
                        maxWords.clear();
                        Rezultat rez = new Rezultat(t.nume_fisier, map, maxWords);
                        Tema2.rezultate[t.id_task] = rez;

                    } else {
                        String content = "";
                        //RandomAccessFile file = new RandomAccessFile(t.nume_fisier, "r");
                        file.seek(t.offset);

                        for (int j = t.offset; j < t.offset + t.dimensiune; j++) {
                            content += (char) file.read();
                        }
                    //    System.out.println(content);

                        Map<Integer, Integer> map = new HashMap<Integer, Integer>();
                        Vector<String> maxWords = new Vector<String>();
                        int maxLength = -20000;
                        StringTokenizer token = new StringTokenizer(content, Tema2.for_check);
                        while (token.hasMoreTokens()) {
                            //System.out.println(token.nextToken().length());
                            String cuvant = token.nextToken();
                            int l = cuvant.length();
                            map.putIfAbsent(l, 0);
                            int increment = map.get(l);
                            increment++;
                            map.replace(l, increment);

                            if (cuvant.length() == maxLength)
                                maxWords.add(cuvant);
                            else if (cuvant.length() > maxLength) {
                                maxLength = cuvant.length();
                                maxWords.clear();
                                maxWords.add(cuvant);
                            }
                        }
                        //System.out.println(maxWords);
                        Rezultat rez = new Rezultat(t.nume_fisier, map, maxWords);
                        Tema2.rezultate[t.id_task] = rez;
                    }

                    //System.out.println(t.offset + "    " + t.dimensiune);
                   // System.out.println("Thread [" + id + "]  :  " + Tema2.taskuri.get(i));
                }
            } catch (IOException ex) {
                System.out.println("Something went Wrong");
                ex.printStackTrace();
            }
        //}
    }

}